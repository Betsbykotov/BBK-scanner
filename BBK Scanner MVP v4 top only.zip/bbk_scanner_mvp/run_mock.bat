@echo off
python -m bbk_scanner.main --provider mock
pause
