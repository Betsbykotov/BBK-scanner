import tempfile
import unittest
from datetime import datetime, timedelta, timezone

from bbk_scanner.analyzer import OddsAnalyzer, pct_change
from bbk_scanner.database import OddsDatabase
from bbk_scanner.models import OddsQuote


def quote(price: float, captured_at: str, bookmaker_key: str = "book-a") -> OddsQuote:
    return OddsQuote(
        event_id="e1",
        sport_key="soccer_test",
        commence_time="2026-08-01T19:00:00Z",
        home_team="Home",
        away_team="Away",
        bookmaker_key=bookmaker_key,
        bookmaker_title=bookmaker_key,
        market_key="totals",
        outcome_name="Over",
        point=2.5,
        price=price,
        captured_at=captured_at,
    )


class AnalyzerTests(unittest.TestCase):
    def test_pct_change(self):
        self.assertAlmostEqual(pct_change(2.0, 2.2), 10.0)

    def test_detects_movement(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as temp:
            db = OddsDatabase(temp.name)
            old_time = (datetime.now(timezone.utc) - timedelta(minutes=31)).isoformat()
            db.insert_quotes([quote(1.80, old_time)])

            current_time = datetime.now(timezone.utc).isoformat()
            current = [
                quote(2.00, current_time, "book-a"),
                quote(1.82, current_time, "book-b"),
            ]
            analyzer = OddsAnalyzer(
                db=db,
                movement_threshold_pct=8,
                market_deviation_threshold_pct=20,
                lookback_minutes=30,
                min_bookmakers=2,
            )
            alerts = analyzer.analyze(current)
            self.assertEqual(len(alerts), 1)
            self.assertGreater(alerts[0].movement_pct, 11)

    def test_bbk_score_ranks_alerts_and_sorts_descending(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as temp:
            db = OddsDatabase(temp.name)
            old_time = (datetime.now(timezone.utc) - timedelta(minutes=31)).isoformat()
            db.insert_quotes(
                [
                    quote(1.80, old_time, "book-a"),
                    quote(1.80, old_time, "book-b"),
                    quote(1.80, old_time, "pinnacle"),
                ]
            )

            current_time = datetime.now(timezone.utc).isoformat()
            current = [
                # Три книги двигаются в одну сторону -> высокий консенсус,
                # плюс sharp-источник -> ожидаем самый высокий score.
                quote(2.10, current_time, "book-a"),
                quote(2.05, current_time, "book-b"),
                quote(2.08, current_time, "pinnacle"),
            ]
            analyzer = OddsAnalyzer(
                db=db,
                movement_threshold_pct=8,
                market_deviation_threshold_pct=50,  # выключаем deviation-триггер
                lookback_minutes=30,
                min_bookmakers=2,
                sharp_bookmakers=("pinnacle",),
            )
            alerts = analyzer.analyze(current)
            self.assertEqual(len(alerts), 3)

            # Отсортировано по убыванию score
            scores = [a.bbk_score for a in alerts]
            self.assertEqual(scores, sorted(scores, reverse=True))

            # Pinnacle (sharp) должен получить бонус и оказаться первым
            self.assertEqual(alerts[0].quote.bookmaker_key, "pinnacle")
            self.assertTrue(alerts[0].is_sharp_source)
            self.assertGreater(alerts[0].consensus_pct, 0)
            self.assertTrue(alerts[0].bbk_tier)

    def test_dedup_blocks_repeat_within_cooldown(self):
        with tempfile.NamedTemporaryFile(suffix=".db") as temp:
            db = OddsDatabase(temp.name)
            now_iso = datetime.now(timezone.utc).isoformat()
            key = "e1:totals:Over:2.5:book-a"

            self.assertFalse(db.was_recently_sent(key, cooldown_minutes=60, now_iso=now_iso))
            db.mark_sent(key, now_iso)
            self.assertTrue(db.was_recently_sent(key, cooldown_minutes=60, now_iso=now_iso))

            # За пределами cooldown алерт снова разрешён
            later_iso = (datetime.now(timezone.utc) + timedelta(minutes=61)).isoformat()
            self.assertFalse(db.was_recently_sent(key, cooldown_minutes=60, now_iso=later_iso))


if __name__ == "__main__":
    unittest.main()
