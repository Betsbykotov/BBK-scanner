#!/usr/bin/env bash
set -euo pipefail
python -m bbk_scanner.main --provider mock
